<?php 

namespace Conekta;

use \Conekta\ConektaResource;

class WebhookLog extends ConektaResource
{
}
