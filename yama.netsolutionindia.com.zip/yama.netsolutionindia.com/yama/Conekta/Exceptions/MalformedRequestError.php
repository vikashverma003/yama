<?php
namespace Conekta;
use \Conekta\Conekta;
use \Conekta\Exceptions;
use \Exception;
class MalformedRequestError extends Handler
{
}
