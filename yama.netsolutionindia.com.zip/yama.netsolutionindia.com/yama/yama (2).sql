-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 19, 2020 at 08:51 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yama`
--

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

DROP TABLE IF EXISTS `buildings`;
CREATE TABLE IF NOT EXISTS `buildings` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `building_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `space` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buildings`
--

INSERT INTO `buildings` (`id`, `building_name`, `image`, `link`, `floor`, `space`, `created_at`, `updated_at`) VALUES
(6, 'TETS', 'http://localhost:8000/admin/images/building/4727afb8f16364b97513dc432ef748ef.jpg', 'https://erptest.code-brew.com/dev/dashboardev', '4', '5478', '2020-07-16 23:24:55', '2020-07-18 07:30:10'),
(7, 'T square', 'http://localhost:8000/admin/images/building/9154fd0fc975a58db0852b3ca3f2203d.jpg', 'https://erptest.code-brew.com/dev/dashboardev', '7', '7676', '2020-07-17 04:34:30', '2020-07-17 04:34:30'),
(8, 'M SQUARE', 'http://localhost:8000/admin/images/building/3e1209101c9073e53f5ebac7f16d69b6.jpg', 'https://erptest.code-brew.com/dev/dashboardev', '9', '87887', '2020-07-18 03:40:18', '2020-07-18 03:40:18');

-- --------------------------------------------------------

--
-- Table structure for table `chat_request`
--

DROP TABLE IF EXISTS `chat_request`;
CREATE TABLE IF NOT EXISTS `chat_request` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `doctor_id` bigint(20) UNSIGNED NOT NULL,
  `is_accept` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_request_patient_id_foreign` (`patient_id`),
  KEY `chat_request_doctor_id_foreign` (`doctor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `building_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `space_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `building_id`, `floor_id`, `space_name`, `event_name`, `event_type`, `event_description`, `created_at`, `updated_at`) VALUES
(1, '6', '6', 'HALL', 'edit', 'mnb', 'nbvnbvnbvnb', '2020-07-17 18:30:00', '2020-07-17 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `floors`
--

DROP TABLE IF EXISTS `floors`;
CREATE TABLE IF NOT EXISTS `floors` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `building_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_rooms` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `floor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `floors`
--

INSERT INTO `floors` (`id`, `building_id`, `number_of_rooms`, `created_at`, `updated_at`, `floor_name`, `floor_number`, `area`, `image`) VALUES
(9, '5', '65', '2020-07-18 00:55:31', '2020-07-18 00:55:31', 'gjhgjh', '6', '87687', 'http://localhost:8000/admin/images/building/c7fdf6d6ecccb8561ca4bf2cda054d58.jpg'),
(8, '5', '98', '2020-07-18 00:20:02', '2020-07-18 00:20:02', 'uyuy', '6', '98989', 'http://localhost:8000/admin/images/building/2cd731d20627246f8873b5c454583066.jpg'),
(10, '5', '8', '2020-07-18 03:42:46', '2020-07-18 03:42:46', 'HFDHGDGHD', '6', '8768768', 'http://localhost:8000/admin/images/building/bf0fd98075d1c225ba09a5c8cecd1cea.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
CREATE TABLE IF NOT EXISTS `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heading` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`id`, `heading`, `restaurant_id`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Chicken', '1', 'A unique name that reflects the Burmese roots of the owner and an amalgamation of his parents’ influence on him.', 'https://yama.netsolutionindia.com/admin/images/doctor/7d5deb1df3081c3b64349a565265ce1a.jpg', '2020-07-06 12:04:08', '2020-07-06 12:38:06');

-- --------------------------------------------------------

--
-- Table structure for table `inventories`
--

DROP TABLE IF EXISTS `inventories`;
CREATE TABLE IF NOT EXISTS `inventories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `food_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `food_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hide` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventories`
--

INSERT INTO `inventories` (`id`, `food_name`, `group_name`, `food_type`, `price`, `taxes`, `hide`, `image`, `sub_group`, `created_at`, `updated_at`) VALUES
(3, 'DAAL', 'SDSD', 'VEG', '343', '87', '0', 'http://localhost:8000/admin/images/inventory/505d6304724f018dca6150fd0b6ed2f6.jpg', 'QWQW', '2020-07-18 08:36:24', '2020-07-18 08:36:24');

-- --------------------------------------------------------

--
-- Table structure for table `kitchens`
--

DROP TABLE IF EXISTS `kitchens`;
CREATE TABLE IF NOT EXISTS `kitchens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gst_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `food` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `vendor_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kitchens`
--

INSERT INTO `kitchens` (`id`, `name`, `logo`, `description`, `gst_number`, `food`, `license_number`, `created_at`, `updated_at`, `vendor_type`) VALUES
(6, 'VENDOR2', 'http://localhost:8000/admin/images/kitchen_logo/063f0f973c0d31e9bbe7a5c500988fef.jpg', 'BV VBVB VBVBNVB', '2323232', 'DFGDFGDFG CBFB', '56756756', '2020-07-18 06:00:07', '2020-07-18 06:00:07', 'VALET'),
(5, 'VENDOR1', 'http://localhost:8000/admin/images/kitchen_logo/b0c7f55a20bb267d50cbbad2d597a5fc.jpg', 'JHGJH  JHVHJGJH', '987987', 'VBVC', '9879879', '2020-07-17 07:30:46', '2020-07-18 05:59:21', 'KITCHEN');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2020_03_13_050724_create_usersinfo_table', 1),
(10, '2020_03_13_093259_create_usersimage_table', 1),
(11, '2020_03_16_120354_create_language_table', 1),
(12, '2020_03_17_063032_create_general_documentation_table', 1),
(13, '2020_03_17_065034_create_billing_data_table', 1),
(14, '2020_03_17_070120_create_use_cfdi_table', 1),
(15, '2020_03_17_070212_create_deposit_data_table', 1),
(16, '2020_03_17_071302_create_fiscal_keys_table', 1),
(17, '2020_03_17_071535_create_medical_chat_table', 1),
(18, '2020_03_17_071919_create_medical_pro_table', 1),
(19, '2020_03_17_072758_create_doctor_status_table', 1),
(20, '2020_03_18_073822_create_chat_request_table', 1),
(21, '2020_03_19_114606_create_chat_message_table', 1),
(22, '2020_03_20_063338_create_medication_recommended_table', 1),
(23, '2020_07_14_110449_create_parking_spaces_table', 2),
(24, '2020_07_14_133645_create_parking_allocations_table', 3),
(25, '2020_07_15_090942_create_buildings_table', 4),
(26, '2020_07_15_120355_create_space_types_table', 5),
(27, '2020_07_15_130548_create_floors_table', 6),
(28, '2020_07_16_064009_create_valets_table', 7),
(29, '2020_07_16_095156_create_kitchens_table', 8),
(30, '2020_07_17_065526_add_parking_space_to_floors', 9),
(31, '2020_07_17_125536_add_vendor_type_to_kitchens', 10),
(32, '2020_07_18_064100_create_owners_table', 11),
(33, '2020_07_18_130956_create_inventories_table', 12),
(34, '2020_07_18_141337_create_events_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

DROP TABLE IF EXISTS `owners`;
CREATE TABLE IF NOT EXISTS `owners` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `name`, `email`, `password`, `company_name`, `mobile_number`, `created_at`, `updated_at`) VALUES
(2, 'ANSARI', 'ans@gmail.com', '$2y$10$3Fi6ORt79dK2FgsBUKQZTO6RhhKf/CcgmNvkSrbGUQ84H5zqrpLXK', 'DEANJOHN.COM', '87979799', '2020-07-18 01:29:13', '2020-07-18 05:48:00'),
(3, 'SUMMIT', 'su@gmail.com', '$2y$10$WhRNhYMLRHHspj7GueBOyOoy1Iq3J3vrmFPEZpgm3FKOlRQa60OLO', 'HXSOLUTION.COM', '98798798', '2020-07-18 03:38:18', '2020-07-18 03:38:18');

-- --------------------------------------------------------

--
-- Table structure for table `parking_allocations`
--

DROP TABLE IF EXISTS `parking_allocations`;
CREATE TABLE IF NOT EXISTS `parking_allocations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking_id` int(11) DEFAULT NULL,
  `allocate_date_time` timestamp NULL DEFAULT NULL,
  `vacant_date_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allocation_date_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_in` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_out` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parking_allocations`
--

INSERT INTO `parking_allocations` (`id`, `shop_id`, `parking_id`, `allocate_date_time`, `vacant_date_time`, `allocation_date_time`, `status_in`, `status_out`, `created_at`, `updated_at`) VALUES
(1, '67', 1, '2020-07-15 00:52:37', '2020-07-15 06:22:37', '2020-07-15 06:14:14', '1', '0', '2020-07-15 00:44:14', '2020-07-15 00:52:37'),
(2, '34', 2, '2020-07-15 00:51:30', '', '2020-07-15 06:21:30', '1', '0', '2020-07-15 00:51:30', '2020-07-15 00:51:30'),
(3, '56', 3, '2020-07-15 00:51:52', '', '2020-07-15 06:21:52', '1', '0', '2020-07-15 00:51:52', '2020-07-15 00:51:52'),
(4, '45', 5, '2020-07-15 01:15:44', '', '2020-07-15 06:45:44', '1', '0', '2020-07-15 01:15:44', '2020-07-15 01:15:44'),
(6, '11', 7, '2020-07-15 01:22:16', '', '2020-07-15 06:52:16', '1', '0', '2020-07-15 01:22:16', '2020-07-15 01:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `parking_spaces`
--

DROP TABLE IF EXISTS `parking_spaces`;
CREATE TABLE IF NOT EXISTS `parking_spaces` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parking_space` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `in_use` int(11) NOT NULL,
  `shop_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parking_spaces`
--

INSERT INTO `parking_spaces` (`id`, `parking_space`, `status`, `in_use`, `shop_id`, `created_at`, `updated_at`) VALUES
(1, 'available', 1, 1, '67', '2020-07-15 00:44:14', '2020-07-15 00:52:37'),
(2, 'available', 1, 1, '34', '2020-07-15 00:51:30', '2020-07-15 00:51:30'),
(3, 'not available', 0, 0, '56', '2020-07-15 00:51:52', '2020-07-15 00:51:52'),
(4, 'available', 1, 1, '45', '2020-07-15 01:14:51', '2020-07-15 01:24:22'),
(7, 'not available', 1, 1, '11', '2020-07-15 01:22:16', '2020-07-15 01:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `space_types`
--

DROP TABLE IF EXISTS `space_types`;
CREATE TABLE IF NOT EXISTS `space_types` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `space_types`
--

INSERT INTO `space_types` (`id`, `category`, `created_at`, `updated_at`) VALUES
(1, 'CONFERENCE HALL', '2020-07-14 18:30:00', '2020-07-18 07:24:07'),
(2, 'CONFERENCE ROOMS', '2020-07-14 18:30:00', '2020-07-18 07:27:05'),
(3, 'Halls\r\n', '2020-07-14 18:30:00', '2020-07-14 18:30:00'),
(4, 'TERRACE', '2020-07-14 18:30:00', '2020-07-18 07:26:50'),
(5, 'Wellness Rooms', '2020-07-14 18:30:00', '2020-07-14 18:30:00'),
(10, 'test sp', '2020-07-17 05:16:38', '2020-07-17 05:16:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'collaboration for 2 adminstaror for 3',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `block_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `role`, `profile_image`, `account_status`, `email_verified_at`, `phone_code`, `phone_number`, `otp`, `device_token`, `password`, `block_status`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Amit', 'Singh', 'amit256599@gmail.com', '3', 'https://yama.netsolutionindia.com/admin/images/doctor/1f1c51f4358658e8269fb49d734e8b62.jpg', '0', NULL, NULL, '6239533122', NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-06-30 14:25:20', '2020-06-30 14:25:20'),
(4, 'John', 'Smith', 'administrator@gmail.com', '3', 'https://yama.netsolutionindia.com/admin/images/doctor/1f1c51f4358658e8269fb49d734e8b62.jpg', '0', NULL, NULL, '32453253453455', NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-06-30 17:07:59', '2020-06-30 17:07:59'),
(5, 'Demo', 'One', 'demo1@gmail.com', '3', 'https://yama.netsolutionindia.com/admin/images/doctor/ad59ecd4b049145ab83dc46c7b03fcab.jpg', '0', NULL, NULL, '+9175675675675', NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-06-30 17:09:59', '2020-06-30 17:09:59'),
(6, 'Demo', '2', 'demo2@gmail.com', '2', 'https://yama.netsolutionindia.com/admin/images/doctor/a4c668811901efc2b7137823727a2590.jpg', '0', NULL, NULL, '+91436457768', NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-06-30 17:10:29', '2020-06-30 17:10:29'),
(7, 'Yama', 'Information', 'yama@gmail.com', '4', 'https://yama.netsolutionindia.com/admin/images/doctor/1f1c51f4358658e8269fb49d734e8b62.jpg', 'active', NULL, NULL, NULL, NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-06-03 00:00:00', '2020-06-10 00:00:00'),
(8, 'NEw', 'Collaborate', 'new@gmail.com', '2', 'https://yama.netsolutionindia.com/admin/images/doctor/05f30722a811f7af28f900e5c0faf5ff.jpg', '0', NULL, NULL, '+918677867857', NULL, NULL, '$2y$10$UQ7KOlcvs2RyKD0.wHphbuYmnvqLSUb5kFaKkf3VM.pJ2gpipIKE2', '0', NULL, '2020-07-01 06:24:39', '2020-07-01 06:24:39'),
(9, 'Dummy', 'John', 'dummy@gmail.com', '2', 'https://yama.netsolutionindia.com/admin/images/doctor/01a5528493bb516a6d6518c15fc85ae4.jpg', '0', NULL, NULL, '+916785674564', NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-07-01 06:27:37', '2020-07-01 06:27:37'),
(10, 'Demo2', 'info', 'demo2@gmail.com', '2', 'https://yama.netsolutionindia.com/admin/images/doctor/430f4c32cc319bbbd6b1943530c45af4.jpg', '0', NULL, NULL, '+915645635333', NULL, NULL, '$2y$10$u4zHx8JrC2CLtd/z54BgoOWaJsAAuuHtNjCY8u36T9S4WJgISdAFa', '0', NULL, '2020-07-01 06:29:25', '2020-07-01 06:29:25'),
(14, 'Amit', 'Singh', 'amitkumar@codebrewinnovations.com', '3', 'https://yama.netsolutionindia.com/admin/images/doctor/5808d32e64990427936f89ace48b003b.png', '0', NULL, NULL, '6233998766', NULL, NULL, '$2y$10$BFhuUFFOiypnNSKGHUu/2ebZrOArjWpOf1ORBs6Nx0B9oLWRqDxnW', '0', NULL, '2020-07-01 14:12:58', '2020-07-01 14:12:58'),
(15, 'Admin', 'Mehra', 'admin@gmail.com', 'admin', 'http://44.224.147.34/5ea1d090eab2b_1587662992.undefined', 'active', NULL, NULL, NULL, NULL, NULL, '$2y$10$T/FizQUbepXT8Dm/BDCGVOUxOTmUK2deGpdPVZktcACSD7/b6Xqpe', '0', NULL, '2020-07-06 01:07:04', '2020-07-06 01:06:02');

-- --------------------------------------------------------

--
-- Table structure for table `valets`
--

DROP TABLE IF EXISTS `valets`;
CREATE TABLE IF NOT EXISTS `valets` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `driving_license_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_expiry_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `valets`
--

INSERT INTO `valets` (`id`, `name`, `driving_license_image`, `person_image`, `license_expiry_date`, `dob`, `created_at`, `updated_at`) VALUES
(1, 'ravi', 'http://localhost:8000/admin/images/valet/660b132d3328ecf2887aa69b1eacbe6b.jpg', 'http://localhost:8000/admin/images/valet/30eb12da345346cad5947d7d3970a17b.jpg', '2020-07-30', '1985-01-01', '2020-07-16 01:54:19', '2020-07-16 04:07:05'),
(2, 'johny', 'http://localhost:8000/admin/images/valet/925324439bf7bc5dc40c10a9d6e20deb.jpg', 'http://localhost:8000/admin/images/valet/41fb2427d9c2c073b18a7e4de75ad6b1.jpg', '2024-01-26', '1994-02-02', '2020-07-16 01:56:36', '2020-07-16 04:11:18'),
(4, 'tom singh', 'http://localhost:8000/admin/images/valet/78db4a98f7ce6655f3c9993809f77718.jpg', 'http://localhost:8000/admin/images/valet/77ebd0c533c71713e645a6d49613ec46.png', '2025-01-04', '1979-01-17', '2020-07-16 05:21:15', '2020-07-16 05:21:42');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_request`
--
ALTER TABLE `chat_request`
  ADD CONSTRAINT `chat_request_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_request_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
