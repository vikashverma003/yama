<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Owner;
use Hash;

class OwnerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $ownerObj;

    public function __construct(Owner $owner)
    {
         $this->ownerObj =$owner;
    }
    public function index()
    {
        $owner=Owner::all();
        return view('admin.owner.owner_list')->with('owner', $owner);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.owner.add_owner');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
        $addData =[
                   'name' => strtoupper($request->input('name')),
                   'email' => $request->input('email'),
                   'password'=>Hash::make($request->input('password')),
                    'company_name'=>strtoupper($request->input('company_name')),
                    'mobile_number' => $request->input('mobile_number'),   
                   ];
                $createdOwner=$this->ownerObj->create_owners($addData);
                if ($createdOwner) {
                                return redirect('admin/owner')->with("su_status", "Owner  information has been added");                  
                        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $owner=Owner::find($id);
        return view('admin.owner.edit_owner')->with('owner',$owner);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $updateData = [
                   'name' => strtoupper($request->input('name')),
                   'mobile_number' => $request->input('mobile_number'),
                   'email' => $request->input('email'),   
                   'company_name' => strtoupper($request->input('company_name')), 
                ];
           $update =  Owner::where(['id'=>$id])->update($updateData);
           return redirect('admin/owner')->with("su_status", "Owner  information has been updated");                  

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
          $delete_owner=Owner::where('id','=', $id)->delete();
         return redirect('admin/owner')->with("su_status", "Deletion has been succsessfull");
    }
}
