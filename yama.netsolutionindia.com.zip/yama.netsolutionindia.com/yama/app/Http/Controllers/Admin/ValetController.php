<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Valet;
use URL;

class ValetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $valetObj;

    public function __construct(Valet $valet)
    {
         $this->valetObj =$valet;
    }
    public function index()
    {
        //
        //echo 232;

        $valet=Valet::all();
        return view('admin.valet.valet_listing')->with('valet', $valet);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        return view('admin.valet.add_valet');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        if ($request->hasFile('driving_license_image')) {
                $file = request()->file('driving_license_image');
                $ext=$file->getClientOriginalExtension();
                $imagename = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/valet', $imagename);
                }

        $url= URL::to('/');
        $drivingImage=$url.'/admin/images/valet/'.$imagename;

         if ($request->hasFile('person_image')) {
                $file = request()->file('person_image');
                $ext=$file->getClientOriginalExtension();
                $imagename1 = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/valet', $imagename1);
                }

        $url= URL::to('/');
        $personImage=$url.'/admin/images/valet/'.$imagename1;

      $addData = [
                   'name' => $request->input('name'),
                   'license_expiry_date' => $request->input('expiry_date'),
                   'driving_license_image'=>$drivingImage,
                   'person_image'=>$personImage,
                   'dob' => $request->input('dob'),   
                ];

                
        $createdValet=$this->valetObj->create_valet($addData);
        if ($createdValet) {
                        return redirect('admin/valet')->with("su_status", "Valet  information has been added");                  
                } 

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        echo "show";
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $valet=Valet::find($id);
        return view('admin.valet.edit_valet')->with('valet', $valet);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //echo $id;die();
         if ($request->hasFile('driving_license_image')) {
                        $file = request()->file('driving_license_image');
                        $ext=$file->getClientOriginalExtension();
                        $imagename = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                        $file->move('admin/images/valet', $imagename);
                        }

                if(!empty($imagename)){            
                $url= URL::to('/');
                $drivingImage=$url.'/admin/images/valet/'.$imagename;
                 }
                 else{
                     $reqInfo=Valet::where('id','=',$id)->first();
                     $drivingImage=$reqInfo->driving_license_image;
                 }

                 if ($request->hasFile('person_image')) {
                        $file = request()->file('person_image');
                        $ext=$file->getClientOriginalExtension();
                        $imagename1 = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                        $file->move('admin/images/valet', $imagename1);
                        }
                  if(!empty($imagename1)){
                    $url= URL::to('/');
                    $personImage=$url.'/admin/images/valet/'.$imagename1;
                    }
                    else
                    {
                         $reqInfo=Valet::where('id','=',$id)->first();
                         $personImage=$reqInfo->person_image;
                    }
                    $updatedData = [
                           'name' => $request->input('name'),
                           'license_expiry_date' => $request->input('expiry_date'),
                           'driving_license_image'=>$drivingImage,
                           'person_image'=>$personImage,
                           'dob' => $request->input('dob'),   
                        ];
                   $update =  valet::where(['id'=>$id])->update($updatedData);
                   return redirect('admin/valet')->with("su_status", "Valet  information has been updated"); 

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $delete_valet=Valet::where('id','=', $id)->delete();
         return redirect('admin/valet')->with("su_status", "Valet has been deleted");
    }
}
