<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ParkingSpace;
use Validator;
use Redirect;
use App\Models\ParkingAllocation;

class ParkingSpaceController extends Controller
{
    //
    protected $parkingObj;
    protected $parkingAllocationObj;

    public function __construct(ParkingSpace $parkingSpace, ParkingAllocation $parkingAllocation)
    {
         $this->parkingObj =$parkingSpace;
         $this->parkingAllocationObj =$parkingAllocation;    
    }

    public function add_parking_space(Request $request){
      return view('admin.parking.add_parking_space');
    }

    public function store_parking_space(Request $request){       
                $addData = [
                    'parking_space' => $request->input('parking_space'),
                    'status' => $request->input('status'),
                    'in_use' => $request->input('in_use'),
                    'shop_id' => $request->input('shop_id'),                        
                ];    
                //$insert =  ParkingSpace::insertGetId($addData);
                $createdParking=$this->parkingObj->create_parking_space($addData);
                $last_id=$createdParking->id;
                $allocation_data=[
                    'parking_id' => $last_id,
                    'shop_id' => $request->input('shop_id'),
                    'allocate_date_time' => date('Y-m-d h:i:s'),
                    'vacant_date_time' =>'',
                    'allocation_date_time' => date('Y-m-d h:i:s'),
                    'status_in' => 1,
                    'status_out' => 0,
                ];
                //$insert_allocation=ParkingAllocation::insertGetId($allocation_data);
                $createdParkingAllocation=$this->parkingAllocationObj->create_parking_allocation($allocation_data);
                if ($createdParking) {
                        return redirect('admin/parking_space_listing')->with("su_status", "Parking space has been added");
                    //return Redirect::back()->with('su_status', 'Parking Space has been added!');
                     //return redirect('/admin/add_parking_Space')->with('su_status', 'Parking Space has been added!');
                } else {
                    return Redirect::back()->with('er_status', 'No Parking Space  added!');
                }
    }

    public function parking_space_listing(Request $reqquest){
        $parking_space = ParkingSpace::all();
        return view('admin.parking.parking_space_listing')->with('parking_space', $parking_space);
    }


    public function update_parking_space($id){
        //echo $id;
        $parking_id = $id;
        $parking_info =  ParkingSpace::where(['id'=>$parking_id])->first();
        if($parking_info->status==1){
            $updateData=['status'=>0, 'in_use'=>0];
            $update =  ParkingSpace::where(['id'=>$parking_id])->update($updateData);
           
        }
        else{
             $updateData=['status'=>1,'in_use'=>1];
             $update =  ParkingSpace::where(['id'=>$parking_id])->update($updateData);
        }

        return redirect::back()->with("su_status", "Parking space has been updated");
    }

    public function update_parking_allocation($id){

        //echo $id;
        $check_allocation=ParkingAllocation::where('parking_id','=', $id)->first();
        $check_parking= ParkingSpace::where(['id'=>$id])->first();
        if($check_parking->in_use==0){
             $updateData=['allocate_date_time'=>date('Y-m-d h:i:s'),'vacant_date_time'=>date('Y-m-d h:i:s'),'status_in'=>1, 'status_out'=>0];
             $update =  ParkingAllocation::where(['parking_id'=>$id])->update($updateData);
             $updateData_parking=['status'=>1, 'in_use'=>1];
             $update_parking =  ParkingSpace::where(['id'=>$id])->update($updateData_parking);
        }
        else{

            return redirect::back()->with("er_status", "no parking available");

        }
        return redirect::back();

    }

    public function edit_parking_space(Request $request,$id){
        $parking_space = ParkingSpace::where('id', '=', $id)->first();
        return view('admin.parking.edit_parking_space')->with('parking_space', $parking_space);
    }

    public function update_parking(Request $request, $id){
        $updated_data=$request->all();
        $data=[
          'shop_id'=> $updated_data['shop_id'],
          'parking_space'=> $updated_data['parking_space'],
          'status'=> $updated_data['status'],
          'in_use'=> $updated_data['in_use'],
          'updated_at'=>date('Y-m-d h:i:s')
        ];
        
        $update_parking =  ParkingSpace::where(['id'=>$id])->update($data);
       //return redirect::back()->with("su_status", "Parking space has been updated");
       return redirect('admin/parking_space_listing')->with("su_status", "Parking space has been updated");
    }

   public function delete_parking(Request $request,$id){

    $delete_parking=ParkingSpace::where('id','=', $id)->delete();
    return redirect('admin/parking_space_listing')->with("su_status", "Deletion has been succsessfull");

   }



}