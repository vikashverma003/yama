<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\Role;
use App\Models\Language;
use App\Models\Video;

use App\User;
class LanguageController extends Controller
{
    /**
     * Login page
     */
    public function index(){
      if (Auth::check()) {
        return redirect('admin/viewLanguage');
      }
      Auth::logout();

  
      return view('admin.login', ['title' => 'Login Page']);
    }

    public function viewLanguage(Request $request){
         $user=Auth::user();
         $language= Language::get();
        return view('admin.language.viewLanguage', ['title' => 'View Language','user'=>$user,'alllanguage'=>$language]);
    } 

    public function addlanguage(Request $request){
      $user=Auth::user();
        return view('admin.language.addLanguage', ['title' => 'Add Language','user'=>$user]);
    }

    public function languages_add(Request $request){
      $reuslt=\DB::table('language')->insert([ ['name' => $request->name]]);
      if($reuslt){
       return redirect('admin/viewLanguage')->with('status','Language Added Successfully');
      }
    }

    public function delete_lang(Request $request){
     
      $result=\DB::table('language')->where('id',$request->user_id)->delete();
      if($result){
         return response()->json(['success' => true,'message' => 'Language Deleted Successfully']);
      }
    }

    public function editLang(Request $request ,$id){
         $user=Auth::user();
         $language= Language::where(['id'=>$id])->first();
         return view('admin.language.editLanguage', ['title' => 'Edit Language','user'=>$user,'language'=>$language]);
    }

    public function updatelanguage(Request $request){
     $result=   Language::where('id',$request->id)->update([
                        'name' => $request->name,
                        'updated_at' => new \DateTime
            ]);
     if($result){
      return redirect('admin/viewLanguage')->with('status','Language updated Successfully');
     }
    }
    public function video(Request $request){
        $user=Auth::user();
        $video= Video::get();
        return view('admin.language.viewVideo', ['title' => 'View Language','user'=>$user,'video'=>$video]);
    }

    public function editVideo(Request $request, $id){
        $user=Auth::user();
        $video= Video::where(['id'=>$id])->first();
        return view('admin.language.editVideo', ['title' => 'View Language','user'=>$user,'video'=>$video]);
    }
    public function uploadVideo(Request $request){
        if ($request->hasFile('video')) {
            $file = request()->file('video');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'mp4' or $ext== '3gp' or $ext== 'mov' or $ext== 'mp3' or $ext== 'wmv'){
            $video = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $video);
            }else{
                return redirect('admin/video')->with('status','Please Use following format for Video mp4,3gp,mov,mp3');
            }
            }
         $result=   Video::where('id',$request->id)->update([
                        'video' => $video,
                        'updated_at' => new \DateTime
            ]);
         return redirect('admin/video')->with('status','Video has been uploaded Successfully.');

    }



}
