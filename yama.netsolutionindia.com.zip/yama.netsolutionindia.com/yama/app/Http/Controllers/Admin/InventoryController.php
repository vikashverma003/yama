<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Inventory;
use URL;

class InventoryController extends Controller
{
    
    protected $inventoryObj;
    public function __construct(Inventory $inventory)
    {
         $this->inventoryObj =$inventory;
    }
    public function index()
    {
        $inventory=Inventory::all();
        return view('admin.inventory.inventory_listing')->with('inventory', $inventory);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.inventory.add_inventory');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         if ($request->hasFile('image')) {
                $file = request()->file('image');
                $ext=$file->getClientOriginalExtension();
                $imagename1 = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/inventory', $imagename1);
                }
        $url= URL::to('/');
        $logo=$url.'/admin/images/inventory/'.$imagename1;
        $addData = [
                   'food_name' => strtoupper($request->input('food_name')),
                   'group_name' => strtoupper($request->input('group_name')),
                   'food_type' =>strtoupper($request->input('food_type')),
                   'price' => strtoupper($request->input('price')),
                   'taxes'=>$request->input('taxes'),
                   'hide'=>0,                
                   'image'=>$logo,
                   'sub_group' => strtoupper($request->input('sub_group')),   
                ];
        $createdInventory=$this->inventoryObj->create_inventory($addData);
        if ($createdInventory) {
                        return redirect('admin/inventory')->with("su_status", "Inventory  information has been added");                  
                }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
