<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Advice extends Model
{
    protected $table = 'medical_advice';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'patient_id', 'doctor_id','request_id','advice'
    ];


    public function createAdvice($data){
      
         $createdUser= self::create(
            [
                'patient_id'     =>  $data['patient_id']??null,
                'doctor_id'      =>  $data['doctor_id']??null,
                'request_id'     =>  $data['request_id']??null,
                'advice'         =>  $data['advice']??null,
            ]
        );

       return $createdUser;
    }
}
