<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Chatrequest extends Model
{
    protected $table = 'chat_request';
    
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'patient_id', 'doctor_id', 'is_accept','price_status'
    ];

}

