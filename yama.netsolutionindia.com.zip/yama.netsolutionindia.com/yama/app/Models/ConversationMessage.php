<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConversationMessage extends Model
{
    protected $table = 'conversation_messages';

    public function sender(){
    	return $this->belongsTo('App\Models\ConversationUser','conversation_user_id','id');
    }
}
