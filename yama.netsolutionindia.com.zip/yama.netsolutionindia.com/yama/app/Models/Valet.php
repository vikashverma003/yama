<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Valet extends Model
{
    //
    protected $table = 'valets';

     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name','driving_license_image','person_image','license_expiry_date','dob'
    ];

    public function create_valet($data){      
         $createdValet= self::create(
            [
                'name'=>$data['name']??null,
                'driving_license_image'=>  $data['driving_license_image']??null,
                'person_image'=>  $data['person_image']??null,
                'license_expiry_date'=>  $data['license_expiry_date']??null,
                'dob'  =>  $data['dob']??null,
            ]
        );

       return $createdValet;
    }

}
