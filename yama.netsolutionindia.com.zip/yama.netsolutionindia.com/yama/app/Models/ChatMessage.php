<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    protected $table = 'chat_message';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'sender_id','receiver_id', 'message','request_id','message_type','image'
    ];

      public function createChat($data){
      
         $createChat= self::create(
            [
                'sender_id'      =>  $data['sender_id']??null,
                'receiver_id'    =>  $data['receiver_id']??null,
                'message'        =>  $data['message']??null,
                'request_id'     =>  $data['request_id']??null,
                'image'          =>  $data['image']??null, 
                'message_type'   =>  $data['message_type']??null  
            ]
        );
         

       return $createChat;
    }
    
}
