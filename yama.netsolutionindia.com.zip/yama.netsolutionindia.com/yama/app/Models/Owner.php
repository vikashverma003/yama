<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Owner extends Model
{
    //
         protected $table = 'owners';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email','password','company_name','mobile_number'
    ];

    public function create_owners($data){      
         $createdOwner= self::create(
            [
                'name'=>$data['name']??null,
                'email' => $data['email']??null,
                'password'=>  $data['password']??null,
                'company_name' =>  $data['company_name']??null,
                'mobile_number' =>  $data['mobile_number']??null,
            ]
        );

       return $createdOwner;
    }

}
