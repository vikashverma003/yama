<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Illuminate\Support\Str;

class Conversation extends Model
{
    protected $table = 'conversations';

    public function users(){
    	return $this->hasMany('App\Models\ConversationUser','conversation_id','id');//->with("user");
    }

    public function receiver(){
    	return $this->hasMany('App\Models\ConversationUser','conversation_id','id')->with("user");
    }
    public function messages(){
    	return $this->hasMany('App\Models\ConversationMessage','conversation_id','id');
    }
    public function countUnread()
    {
        return $this->hasMany('App\Models\ConversationMessage','conversation_id','id');//->with("sender");
//        return DB::table("conversations as c")
//                ->selectRaw('count(cm.id)')
//                ->join("conversation_messages as cm", "cm.conversation_id", "c.id")
//                ->join("conversation_users as cu", "cu.id", "cm.conversation_user_id")
//                ->where("cu.user_id","!=", 5)
////                ->where("cm.conversation_id",$convers_id)
//                ->where("cm.is_read", "0")
//                ->get();
    }

    public function last_message(){
        return $this->hasOne('App\Models\ConversationMessage','conversation_id','id')->with("sender")->orderBy('id', 'desc');
    }

    public static function createNew($group_name=null,$owner_id=null,$image=''){
    	$is_group = 0;
        $is_active = 0;
    	if($group_name){
    		$is_group = 1;
            $is_active=1;
        }

    	$code = time().''.Str::random(60);

    	return DB::table('conversations')->insertGetId([
    		'name'		=>	$group_name,
    		'code'		=>	$code,
    		'is_group'	=>	$is_group,
            'is_active' =>  $is_active,
    		'created_at'=>	Carbon::now(),
    		'updated_at'=>	Carbon::now()
    		]);
    }

    public static function updateGroup($conversation_id,$name,$image){
        $update = array('name'=>$name);
        if($image)
            $update['image'] = $image;
        DB::table('conversations')->where('id',$conversation_id)->update($update);
    }

    public static function saveMessage($conversation_id,$conversation_user_id,$message,$image,$video,$attachment,$attachment_name,$message_type, $app_msg_id, $is_read){

        // set the conversation active on first message //
        DB::table('conversations')->where('id',$conversation_id)->update([
            'is_active' =>  1
            ]);

        return DB::table('conversation_messages')->insertGetId([
            'app_message_id'        =>  $app_msg_id,
            'conversation_id'       =>  $conversation_id,
            'conversation_user_id'  =>  $conversation_user_id,
            'message'               =>  $message,
            'image'                 =>  $image,
            'video'                 =>  $video,
            'attachment'            =>  $attachment,
            'attachment_name'       =>  $attachment_name,
            'message_type'          =>  $message_type,
            'is_read'               =>  $is_read,
            'created_at'            =>  Carbon::now(),
            'updated_at'            =>  Carbon::now()
            ]);
    }

    public static function deleteGroup($conversation_id,$owner_id){
        $deleted  = DB::table('conversations')->where('id',$conversation_id)->where('is_group',1)->where('owner_id',$owner_id)->delete();
        if($deleted){
            // delete the user and messages //
            DB::table('conversation_users')->where('conversation_id',$conversation_id)->delete();
            // delete messages //
            DB::table('conversation_messages')->where('conversation_id',$conversation_id)->delete();
        }
        return 1;
    }

    public static function exitGroup($conversation_id,$user_id,$sent_as){
        return DB::table('conversation_users')->where('conversation_id',$conversation_id)
            ->where('user_id',$user_id)
            ->where('sent_as',$sent_as)
            ->update(['is_active'=>0]);
    }

    public static function muteGroup($conversation_id,$user_id,$sent_as){
        return DB::table('conversation_users')->where('conversation_id',$conversation_id)
            ->where('user_id',$user_id)
            ->where('sent_as',$sent_as)
            ->update(['is_mute'=>1]);
    }

    public static function blockUser($conversation_id,$conversation_user_id){
        DB::table('conversation_users')->where('id',$conversation_user_id)->where('conversation_id',$conversation_id)->update([
            'blocked_by_other' => 1
            ]);
        return 1;
    }

    public static function unblockUser($conversation_id,$conversation_user_id){
        DB::table('conversation_users')->where('id',$conversation_user_id)->where('conversation_id',$conversation_id)->update([
            'blocked_by_other' => 0
            ]);
        return 1;
    }

    public static function updateMaxReadId($conversation_user_id,$message_id){
        DB::table('conversation_users')->where('id',$conversation_user_id)->update([
            'max_read_id'   =>  $message_id
            ]);
    }
}
