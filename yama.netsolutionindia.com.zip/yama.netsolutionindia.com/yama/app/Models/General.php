<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class General extends Model
{
    protected $table = 'general_documentation';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'professional_card', 'professional_document','professional_title','official_identification','ssa_registration','curp','curp_document','rfc','rfc_document','proof_address','address_document'
    ];

    public function createGeneral($data){
      
        $createGeneral= self::create(
            [
                'professional_card'       =>  $data['professional_card']??null,
                'professional_document'   =>  $data['professional_document']??null,
                'professional_title'      =>  $data['professional_title']??null,
                'official_identification' =>  $data['official_identification']??null,
                'curp'                    =>  $data['curp']??null,
                'curp_document'           =>  $data['curp_document']??null,
                'rfc'                     =>  $data['rfc']??null,
                'rfc_document'            =>  $data['rfc_document']??null,
                'proof_address'           =>  $data['proof_address']??null,
                'ssa_registration'        =>  $data['ssa_registration']??null,
                'address_document'        =>  $data['address_document']??null,
                'user_id'                 =>  $data['user_id']??null,

            ]
        );
        
       return $createGeneral;
    }
}
