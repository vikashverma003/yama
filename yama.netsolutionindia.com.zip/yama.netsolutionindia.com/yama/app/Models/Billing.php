<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Billing extends Model
{
    protected $table = 'billing_data';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'company_name', 'name_rfc','address','number','municipality','state','country','colonia','zipcode','telephone','mail'
    ];

    public function createBilling($data){
      
        $createBilling= self::create([
                'company_name'         =>  $data['company_name']??null,
                'name_rfc'             =>  $data['name_rfc']??null,
                'address'              =>  $data['address']??null,
                'number'               =>  $data['number']??null,
                'municipality'         =>  $data['municipality']??null,
                'state'                =>  $data['state']??null,
                'zipcode'              =>  $data['zipcode']??null,
                'country'              =>  $data['country']??null,
                'colonia'              =>  $data['colonia']??null,
                'telephone'            =>  $data['telephone']??null,
                'mail'                 =>  $data['mail']??null,
                'user_id'              =>  $data['user_id']??null, 
            ]
        );
        
       return $createBilling;
    }
}
