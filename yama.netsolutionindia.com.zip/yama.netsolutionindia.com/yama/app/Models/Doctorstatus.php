<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Doctorstatus extends Model
{
    protected $table = 'doctor_status';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'pre_registration', 'presentation','interview','contract','photo_registration','activation','document_registration'
    ];

    public function createDoctorstatus($data){
      
        $createDoctorstatus= self::create([
                'pre_registration'       =>  $data['pre_registration']??null,
                'presentation'           =>  $data['presentation']??null,
                'interview'              =>  $data['interview']??null,
                'contract'               =>  $data['contract']??null,
                'photo_registration'     =>  $data['photo_registration']??null,
                'activation'             =>  $data['activation']??null,
                'document_registration'  =>  $data['document_registration']??null,
                'user_id'                =>  $data['user_id']??null,
            ]
        );
        
       return $createDoctorstatus;
    }
}
