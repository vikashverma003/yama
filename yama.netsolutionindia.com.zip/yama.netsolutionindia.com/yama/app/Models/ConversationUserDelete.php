<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConversationUserDelete extends Model
{
    protected $table = 'conversation_user_delete';
}
