<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cfdi extends Model
{
    protected $table = 'use_cfdi';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'purchase_goods', 'returns','accessories','general_expenses','telephone_communications','satellite_communications','hospital_fees','handicap','medical_expenses','insurance_premiums','educational_services','be_defined'
    ];

    public function createCfdi($data){
      
        $createCfdi= self::create([
                'purchase_goods'           =>  $data['purchase_goods']??null,
                'returns'                  =>  $data['accessories']??null,
                'accessories'              =>  $data['accessories']??null,
                'general_expenses'         =>  $data['general_expenses']??null,
                'telephone_communications' =>  $data['telephone_communications']??null,
                'satellite_communications' =>  $data['satellite_communications']??null,
                'hospital_fees'            =>  $data['hospital_fees']??null,
                'handicap'                 =>  $data['handicap']??null,
                'insurance_premiums'       =>  $data['insurance_premiums']??null,
                'educational_services'     =>  $data['educational_services']??null,
                'medical_expenses'         =>  $data['medical_expenses']??null,
                'be_defined'               =>  $data['be_defined']??null,
                'user_id'                  =>  $data['user_id']??null, 
            ]
        );
        
       return $createCfdi;
    }
}
