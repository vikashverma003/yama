<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Recommended extends Model
{
    protected $table = 'medication_recommended';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id','patient_id', 'doctor_id', 'request_id','name','dosage','no_day','frequency','instruction','route_administrations','date','presentation'
    ];


    public function createRecomend($data){
       
      if(!empty($data['frequency'])){
       $frequency=  implode(',',$data['frequency']);
       }else{
       $frequency='';
       }
        

         $createRecomend= self::create(
            [
                'patient_id'               =>  $data['patient_id']??null,
                'doctor_id'                =>  $data['doctor_id']??null,
                'request_id'               =>  $data['request_id']??null,
                'name'                     =>  $data['name']??null,
                'dosage'                   =>  $data['dosage']??null,
                'presentation'             =>  $data['presentation']??null,
                'no_day'                   =>  $data['no_day']??null,
                'frequency'                =>  $frequency??null,
                'instruction'              =>  $data['instruction']??null,
                'route_administrations'    =>  $data['route_administrations']??null,
                'date'                     =>  date('Y-m-d'),
            ]
        ); 
       return $createRecomend;
    }

    public function notificationMedication()
    {
        return $this->hasMany(\App\Models\NotificationMedication::class,"medication_id","id");
    }

    
    
}
