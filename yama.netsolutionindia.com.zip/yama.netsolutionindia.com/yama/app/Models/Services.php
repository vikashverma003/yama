<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
    protected $table = 'services';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id','question', 'answer','image','phonenumber','question_sp','answer_sp'
    ];


    public function createServices($data){
      
         $createdUser= self::create(
            [
                'question'     =>  $data['question']??null,
                'question_sp'  =>  $data['question_sp']??null,
                'answer'       =>  $data['answer']??null,
                'answer_sp'    =>  $data['answer_sp']??null,
                'image'        =>  $data['image']??null,
                'phonenumber'  =>  $data['phonenumber']??null,
            ]
        );

       return $createdUser;
    }
}
