<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ParkingSpace extends Model
{
    //
    protected $table = 'parking_spaces';

     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'parking_space', 'status','in_use','shop_id'
    ];

    public function create_parking_space($data){      
         $createdSpace= self::create(
            [
                'parking_space'=>$data['parking_space']??null,
                'status' => $data['status']??null,
                'in_use'=>  $data['in_use']??null,
                'shop_id'  =>  $data['shop_id']??null,
            ]
        );

       return $createdSpace;
    }

  
}
