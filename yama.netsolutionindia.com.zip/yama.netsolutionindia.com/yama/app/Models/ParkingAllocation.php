<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ParkingAllocation extends Model
{
    //
    protected $table = 'parking_allocations';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'shop_id', 'parking_id','allocate_date_time','vacant_date_time','allocation_date_time','status_in','status_out',
    ];

    public function create_parking_allocation($data){      
         $createdAllocation= self::create(
            [
                'shop_id'=>$data['shop_id']??null,
                'parking_id' => $data['parking_id']??null,
                'allocate_date_time'=>  $data['allocate_date_time']??null,
                'vacant_date_time' =>  $data['vacant_date_time']??null,
                'allocation_date_time' =>  $data['allocation_date_time']??null,
                'status_in' =>  $data['status_in']??null,
                'status_out' =>  $data['status_out']??null,
            ]
        );

       return $createdAllocation;
    }
}
