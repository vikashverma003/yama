<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Patientrating extends Model
{
    protected $table = 'patient_rating';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_id','patient_id','comment','rating','cooperetive','mannered','understanding','consultation','rude','help','uncomfortable','unprofessional'
    ];

    public function createRating($data){
     print_r($data);
     die();
        $createdUsers= self::create(
            [
                'patient_id'     =>  $data['patient_id']??null,
                'doctor_id'      =>  $data['doctor_id']??null,
                'rating'         =>  $data['rating']??null,
                'comment'        =>  $data['comment']??null,
                'cooperetive'    =>  $data['cooperetive']??null,
                'mannered'       =>  $data['mannered']??null,
                'understanding'  =>  $data['understanding']??null,
                'consultation'   =>  $data['consultation']??null,
                'rude'           =>  $data['rude']??null,
                'help'           =>  $data['help']??null,
                'uncomfortable'  =>  $data['uncomfortable']??null,
                'unprofessional' =>  $data['unprofessional']??null,
            ]
        );
       return $createdUsers;
    }
}
