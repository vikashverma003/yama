<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConversationUser extends Model
{
    protected $table = 'conversation_users';

    public function user(){
    	return $this->belongsTo('App\User','user_id','id');
    }

    public function chat_message(){
    	return $this->belongsTo('App\Models\ConversationMessage','conversation_id','conversation_id');
    }

    public function assignment(){
    	return $this->belongsTo('App\Models\Assignment','assignment_id','id');
    }
}
