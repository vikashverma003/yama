<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
     //
    protected $table = 'inventories';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'food_name', 'group_name','food_type','price','taxes','hide','image','sub_group'
    ];

    public function create_inventory($data){      
         $createdInventory= self::create(
            [
                'food_name'=>$data['food_name']??null,
                'group_name' => $data['group_name']??null,
                'food_type'=>  $data['food_type']??null,
                'price' =>  $data['price']??null,
                'taxes' =>  $data['taxes']??null,
                'hide' =>  $data['hide']??null,
                'image' =>  $data['image']??null,
                'sub_group' =>  $data['sub_group']??null,
            ]
        );
       return $createdInventory;
    }
}
