<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kitchen extends Model
{
    //
    protected $table = 'kitchens';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'logo','description','gst_number','food','license_number','vendor_type'
    ];

    public function create_kitchen($data){      
         $createdKitchen= self::create(
            [
                'name'=>$data['name']??null,
                'logo' => $data['logo']??null,
                'description'=>  $data['description']??null,
                'gst_number' =>  $data['gst_number']??null,
                'food' =>  $data['food']??null,
                'license_number' =>  $data['license_number']??null,
                'vendor_type' =>  $data['vendor_type']??null,


            ]
        );
       return $createdKitchen;
    }

}
