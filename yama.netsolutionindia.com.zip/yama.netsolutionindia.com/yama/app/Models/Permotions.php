<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Permotions extends Model
{
    protected $table = 'permotions';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'heading','off','image','heading_es'
    ];


    public function createPermotions($data){
      
         $createdUser= self::create(
            [
                'heading'     =>  $data['heading']??null,
                'heading_es'  =>  $data['heading_es']??null,
                'off'         =>  $data['off']??null,
                'image'       =>  $data['image']??null,
            ]
        );

       return $createdUser;
    }
}
