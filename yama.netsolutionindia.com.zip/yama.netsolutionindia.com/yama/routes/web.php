<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

    
Route::namespace('Admin')->prefix('admin')->group(function () {
    Route::get('login','UserController@index')->name('login');
    Route::post('check_user','UserController@login');
    Route::get('term','UserController@term');
    Route::get('privacy','UserController@privacy');
    Route::get('add_parking_space','ParkingSpaceController@add_parking_space');
    Route::post('store_parking_space','ParkingSpaceController@store_parking_space');
    Route::get('parking_space_listing','ParkingSpaceController@parking_space_listing');
    Route::get('update_parking_space/{id}','ParkingSpaceController@update_parking_space');
    Route::get('update_parking_allocation/{id}','ParkingSpaceController@update_parking_allocation');
    Route::get('edit_parking_space/{id}','ParkingSpaceController@edit_parking_space');
    Route::post('edit_parking_space/{id}','ParkingSpaceController@update_parking');
    Route::get('delete_parking/{id}','ParkingSpaceController@delete_parking');

    Route::get('add_building','BuildingController@create_building');
    Route::post('store_building','BuildingController@store_building');
    Route::get('building_list','BuildingController@building_listing');
    Route::get('building_edit/{id}','BuildingController@building_edit');
    Route::post('building_edit/{id}','BuildingController@building_edit_update');
    Route::get('delete_building/{id}','BuildingController@delete_building');
    Route::get('add_floor_details/{id}','BuildingController@add_floor_details');
    Route::post('store_floor_details','BuildingController@store_floor_details');
    Route::get('floor_listing/{id}','BuildingController@floor_listing');
    Route::get('building_floor_listing','BuildingController@building_floor_listing');



    Route::resource('valet','ValetController');
    Route::post('valet/{id}/update', ['as' => 'valet.update', 'uses' => 'ValetController@update']);
    Route::get('valet/{id}/delete', ['as' => 'valet.delete', 'uses' => 'ValetController@destroy']);

    Route::resource('kitchen', 'KitchenController');
    Route::post('kitchen/{id}/update', ['as' => 'kitchen.update', 'uses' => 'KitchenController@update']);
    Route::get('kitchen/{id}/delete', ['as' => 'kitchen.delete', 'uses' => 'KitchenController@destroy']);

    Route::resource('spacetype','SpaceTypeController');
    Route::post('spacetype/{id}/update', ['as' => 'spacetype.update', 'uses' => 'SpaceTypeController@update']);
    Route::get('spacetype/{id}/delete', ['as' => 'spacetype.delete', 'uses' => 'SpaceTypeController@destroy']);

    Route::resource('owner','OwnerController');
    Route::post('owner/{id}/update', ['as' => 'owner.update', 'uses' => 'OwnerController@update']);
    Route::get('owner/{id}/delete', ['as' => 'owner.delete', 'uses' => 'OwnerController@destroy']);


    Route::resource('inventory','InventoryController');
    Route::post('owner/{id}/update', ['as' => 'owner.update', 'uses' => 'OwnerController@update']);
    Route::get('owner/{id}/delete', ['as' => 'owner.delete', 'uses' => 'OwnerController@destroy']);

    Route::resource('event','EventController');


    Route::middleware(['auth'])->group(function () {

        Route::get('dashboard','DashboardController@index');
        Route::get('viewPayment','PaymentController@viewPayment');
        Route::get('logout','UserController@logout');
        Route::get('users','UserController@users');
        Route::get('group','UserController@group');
        Route::get('patientInformation','UserController@patientInformation');
        
        //Route::get('viewUser/{id}','UserController@viewUser');
        Route::get('/viewUser/{id}',['as'=>'viewUser', 'uses' => 'UserController@viewUser']);
        Route::get('/trustedDoctor/{id}',['as'=>'trustedDoctor', 'uses' => 'UserController@trustedDoctor']);
        
        Route::get('/paidChatDoctor/{id}',['as'=>'paidChatDoctor', 'uses' => 'UserController@paidChatDoctor']);
        

        Route::get('/viewTransaction/{id}',['as'=>'viewTransaction', 'uses' => 'PaymentController@viewTransaction']);
        
        Route::get('/changeStatus/{id}',['as'=>'changeStatus', 'uses' => 'PaymentController@changeStatus']);
         
        
        Route::get('/user/block',['as'=>'block_user','uses' => 'UserController@block_user']);
        Route::get('/user/approved',['as'=>'block_user','uses' => 'UserController@approved']);
        Route::get('/user/delete',['as'=>'delete_user','uses' => 'UserController@delete_user']);

        //Doctors
        Route::get('doctors','DoctorsController@index');
        //approveddoctors
        Route::get('presentation','UserController@presentation');
        
        Route::get('viewDoctors','DoctorsController@viewDoctors');
        Route::get('approveddoctors','DoctorsController@approveddoctors');
        Route::get('adddoctors','DoctorsController@add');

        Route::get('addGroup','UserController@addGroup');
        Route::post('updateGroup','UserController@updateGroup');
        Route::post('createGroup','UserController@createGroup');

       Route::get('/viewGroup/{id}',['as'=>'viewGroup', 'uses' => 'UserController@editGroup']);
        


       
        
        
        
        Route::post('updatelanguage','LanguageController@updatelanguage');
        Route::post('updateDeaseas','DoctorsController@updateDeaseas');
        Route::get('/user/deleteService',['as'=>'delete_services','uses' => 'UserController@delete_services']);

        Route::get('/user/delete_presentation',['as'=>'delete_presentation','uses' => 'UserController@delete_presentation']);
        
       Route::get('/user/delete_root',['as'=>'delete_root','uses' => 'UserController@delete_root']);

        Route::get('/deletePermotions',['as'=>'delete_permotions','uses' => 'UserController@delete_permotions']);
        
        Route::get('/user/deleteLanguage',['as'=>'delete_lang','uses' => 'LanguageController@delete_lang']);
        Route::get('/deleteDisease',['as'=>'delete_disease','uses' => 'DoctorsController@delete_disease']);
        
        Route::get('/user/editlang/{id}',['as'=>'editLang', 'uses' => 'LanguageController@editLang']);
        Route::get('/editServices/{id}',['as'=>'editServices', 'uses' => 'UserController@editServices']);
        
         Route::get('/editroot/{id}',['as'=>'editroot', 'uses' => 'UserController@editroot']);
        
        Route::get('/editPermotions/{id}',['as'=>'editPermotions', 'uses' => 'UserController@editPermotions']);

        Route::get('/emailShoot/{id}',['as'=>'emailShoot', 'uses' => 'UserController@emailShoot']);

    });
});

Route::namespace('Web')->group(function () {
    Route::get('/','HomeController@index')->name('home');
    Route::resource('login','LoginController');
    //Route::namespace('Owner')->prefix('admin')->group(function () {
    Route::get('owner/userlist','UserController@userlist');
    Route::post('owner/createUser','UserController@createUser');
    Route::get('owner/signin','UserController@signin');
    Route::post('loginUser','UserController@loginUser');
    
    Route::get('logout','UserController@logout');
    //Collaborations
    Route::get('collaborator/signin','CollaboratorController@collaborator_signin');
    Route::post('collaborator/loginCollaorator','CollaboratorController@loginCollaorator');
    Route::get('collaborator','CollaboratorController@index');
    
    //Aminstrator
   Route::get('administrator/signin','AdministratorController@administrator_signin');
   Route::post('administrator/loginAdministrator','AdministratorController@loginAdministrator');
   Route::get('administrator','AdministratorController@index');
    //});
     });
