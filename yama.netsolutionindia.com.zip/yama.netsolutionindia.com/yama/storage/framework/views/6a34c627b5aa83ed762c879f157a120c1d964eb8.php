<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Inventory</h4>
            
             <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/inventory')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <div class="row">
                           <div class="col-md-6">
                          <label for="exampleInputEmail1">Food Name</label>
                          <input type="text" name="food_name" class="form-control" id="exampleInputEmail1" placeholder="food_name" required>
                         </div>

                         <div class="col-md-6">
                                <label for="title" class="exampleInputEmail1">Food Type</label>
                                      <select  id="vendor_type" name="food_type" class="form-control">
                                       <option value="veg">Veg</option>
                                        <option value="non-veg">Non-veg</option>
                                      </select>                                    
                            </div>
                          </div></div>

                             <div class="form-group ">
                              <div class="row">
                              <div class="col-md-6">
                                  <label for="exampleInputEmail1">Group Name</label>
                                  <input type="text" name="group_name" class="form-control" id="exampleInputEmail1" placeholder="group_name" required>
                                 </div> 
                               
                               <div class="col-md-6">
                                  <label for="exampleInputEmail1">Sub Group</label>
                                  <input type="text" name="sub_group" class="form-control" id="exampleInputEmail1" placeholder="sub_group" required="">
                                 </div>
                                   </div></div>  
                          
                           <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                          <label for="exampleInputEmail1">Price</label>
                          <input type="number" name="price" class="form-control" id="exampleInputEmail1" placeholder="price" required>

                             </div>
                             <div class="col-md-6">
                          <label for="exampleInputEmail1">Image</label>
                          <input type="file" name="image" class="form-control" id="exampleInputEmail1" placeholder="image" required>
                             </div></div></div>
                                <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                          <label for="exampleInputEmail1">Tax</label>
                          <input type="number" name="taxes" class="form-control" id="exampleInputEmail1" placeholder="taxes" required>
                             </div>
                             </div></div>

                              

                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>    
          </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/inventory/add_inventory.blade.php ENDPATH**/ ?>