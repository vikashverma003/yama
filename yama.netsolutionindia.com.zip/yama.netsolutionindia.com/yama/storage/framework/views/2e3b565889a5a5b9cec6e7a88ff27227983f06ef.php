<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
                <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
                <a href="<?php echo e(url('admin/add_building')); ?>" class="btn addLangBtn">
                  ADD BUILDING
                          </a>
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Building Id</th>
                            <th width="5%">Building Name</th>
                            <th width="5%">Image</th>
                            <th width="5%">Link</th>
                            <th width="5%">Floor</th>
                            <th width="5%">Space</th>
                            <th width="5%">Action</th>
                            <th width="5%">Add Floor</th>
                            <!--<th width="5%">Floor Details</th> -->
                        </tr>
                      </thead>

                      <tbody>
                        <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buildingss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($buildingss->id); ?></td>
                            <td><?php echo e($buildingss->building_name); ?></td>
                            <td><img src="<?php echo e($buildingss->image); ?>" width="100" height="100" alt="image"/></td>
                            <td><?php echo e($buildingss->link); ?></td>  
                            <td><?php echo e($buildingss->floor); ?></td>                            
                           <td><?php echo e($buildingss->space); ?></td> 
                          <!-- <td>
                              <a href="<?php echo e(url('/admin/building_edit')); ?>/<?php echo e($buildingss->id); ?>">Edit</a>
                            
                              <a href="<?php echo e(url('/admin/delete_building')); ?>/<?php echo e($buildingss->id); ?>">Delete</a>
                            </td>  -->
                            <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(url('/admin/building_edit')); ?>/<?php echo e($buildingss->id); ?>" class="dropdown-item" >Edit</a>
                                      <a href="<?php echo e(url('/admin/delete_building')); ?>/<?php echo e($buildingss->id); ?>" class="dropdown-item" >Delete</a>

                                  </div>
                                </li>
                              </ul>
                            </td> 

                        <td><a href="<?php echo e(url('/admin/add_floor_details')); ?>/<?php echo e($buildingss->id); ?>">Add</a></td> 
                            <!--<td><a href="<?php echo e(url('/admin/floor_listing')); ?>/<?php echo e($buildingss->id); ?>">Details</a></td> -->

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/building/building_list.blade.php ENDPATH**/ ?>