<footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-12  col-12">
                    <ul>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Terms & conditions</a></li>
                        <li><a href="#">Privacy policy</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <ul>
                        <li>
                            <h4>home <b>For talent</b></h4>
                        </li>
                        <li><a href="#">Sign in</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6 ">
                    <ul>
                        <li>
                            <h4>home <b>For employers</b> </h4>
                        </li>
                        <li><a href="#">Sign in</a></li>
                        <li><a href="#">FAQ’s</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 offset-lg-3 col-md-3">
                    <a href="index.html" class="footer-logo">
                        <img src="<?php echo e(asset('web/images/logo (1).png')); ?>" alt="">
                        <p>where talent works</p>
                    </a>
                </div>
            </div>
        </div>
        <div class="footer-btm">
            <div class="container">
                <div class="row">

                    <div class="col-md-12">
                        <ul class="social_links">
                            <li>
                                <a href="#">
                                    <img src="<?php echo e(asset('web/images/twitter-brands.svg')); ?>" alt="">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="<?php echo e(asset('web/images/facebook-square-brands.svg')); ?>" alt="">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="<?php echo e(asset('web/images/instagram-brands.svg')); ?>" alt="">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="<?php echo e(asset('web/images/linkedin-brands.svg')); ?>" alt="">
                                </a>
                            </li>
                        </ul>

                        <span> © Copyright 2019 | All rights reserved</span>
                    </div>


                </div>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\giggers\resources\views/web/includes/footer.blade.php ENDPATH**/ ?>