<header>
        <div class="navigation-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <nav class="navbar navbar-expand-md">

                            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('web/images/header_logo.png')); ?>" alt="">
                            </a>
                          <?php $data= Auth::user() ?>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto py-4 py-md-0">
                                    <li class="nav-item pl-md-0 ml-0 ml-md-4">
                                        <a class="nav-link" href="#">
                                            <img src="<?php echo e(asset('web/images/request.png')); ?>" alt="" class="requestIcon">
                                            Request
                                        </a>

                                    </li>

                                      <?php if(@$data->role == '4'): ?>
                                    <li class="nav-item pl-md-0 ml-0 ml-md-4">
                                        <a class="nav-link toggleDiv">
                                            <img src="<?php echo e(asset('web/images/thomas m.png')); ?>" alt="" class="profileIcon">
                                           <?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?>

                                            <img src="<?php echo e(asset('web/images/dropdown.png')); ?>" alt="" class="dropdownIcon">
                                        </a>
                                    </li>
                                </ul>

                                <div class="profileMenu">
                                    <ul>
                                         
                                        <li>
                                            <a href="#">
                                                Bookings/Request
                                            </a>
                                        </li>

                                       

                                  
                                        <li>
                                            <a href="#">
                                                My Account
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('owner/userlist')); ?>">
                                                My Users
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                Contact us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                Help
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(url('logout')); ?>">
                                                Sign out
                                            </a>
                                        </li>
                                        <?php elseif(@$data->role =='2'): ?>
                                           <li class="nav-item pl-md-0 ml-0 ml-md-4">
                                        <a class="nav-link toggleDiv">
                                            <img src="<?php echo e(asset('web/images/thomas m.png')); ?>" alt="" class="profileIcon">
                                           <?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?>

                                            <img src="<?php echo e(asset('web/images/dropdown.png')); ?>" alt="" class="dropdownIcon">
                                        </a>
                                    </li>
                                </ul>

                                <div class="profileMenu">
                                    <ul>
                                         
                                        
                                        <li>
                                            <a href="<?php echo e(url('logout')); ?>">
                                                Sign out
                                            </a>
                                        </li>
                                         <?php elseif(@$data->role =='3'): ?>
                                            <li class="nav-item pl-md-0 ml-0 ml-md-4">
                                        <a class="nav-link toggleDiv">
                                            <img src="<?php echo e(asset('web/images/thomas m.png')); ?>" alt="" class="profileIcon">
                                           <?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?>

                                            <img src="<?php echo e(asset('web/images/dropdown.png')); ?>" alt="" class="dropdownIcon">
                                        </a>
                                    </li>
                                </ul>

                                <div class="profileMenu">
                                    <ul>
                                         
                                        
                                        <li>
                                            <a href="<?php echo e(url('logout')); ?>">
                                                Sign out
                                            </a>
                                        </li>
                                          <?php else: ?>
                                         <!-- <li>
                                            <a href="<?php echo e(url('owner/signin')); ?>">
                                                Sign In
                                            </a>
                                        </li> -->
                                        <li class="nav-item pl-md-0 ml-0 ml-md-4">
                                        <a href="<?php echo e(url('owner/signin')); ?>" class="nav-link">
                                            <img src="<?php echo e(asset('web/images/thomas m.png')); ?>" alt="" class="profileIcon">
                                            Sign In
                                           
                                        </a>
                                    </li>

                                        <?php endif; ?>

                                    </ul>
                                </div>

                            </div>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header><?php /**PATH /var/www/html/yama.netsolutionindia.com/yama/resources/views/web/includes/header.blade.php ENDPATH**/ ?>