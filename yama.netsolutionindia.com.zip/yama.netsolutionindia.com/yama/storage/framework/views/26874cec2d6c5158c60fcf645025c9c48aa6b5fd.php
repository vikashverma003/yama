<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
                <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
                <!-- <a href="<?php echo e(url('admin/add_building')); ?>" class="btn addLangBtn">
                  ADD BUILDING
                          </a> -->
                           <h4 class="card-title">Floors Listing</h4>
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Floor Id</th>
                            <th>Floor Name</th>
                            <th width="5%">Building Name</th>
                            <th>Room Number</th>
                            <th width="5%">Floor Image</th>
                            <th> Number of Rooms</th>
                            
                        </tr>
                      </thead>

                      <tbody>
                        <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($floors['id']); ?></td>
                            <td><?php echo e($floors['floor_name']); ?></td>       
                            <td><?php echo e($floors['building_name']); ?></td>
                           <td><?php echo e($floors['floor_number']); ?></td> 
                            <td><img src="<?php echo e($floors['image']); ?>" width="100" height="100" alt="image"/></td>
                            <td><?php echo e($floors['number_of_rooms']); ?></td>  
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/building/building_floor_listing.blade.php ENDPATH**/ ?>