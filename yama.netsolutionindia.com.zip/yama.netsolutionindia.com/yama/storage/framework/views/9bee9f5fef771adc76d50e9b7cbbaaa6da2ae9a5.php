<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Vendor</h4>
            
             <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/kitchen')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                          <div class="col-md-6">
                                <label for="title" class="exampleInputEmail1">Vendor Type</label>
                                      <select  id="vendor_type" name="vendor_type" class="form-control">
                                       <option value="">Select Vendor Type</option>
                                       <option value="valet">Valet</option>
                                        <option value="kitchen">Kitchen</option>
                                      </select>                                    
                            </div>
                          </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label>
                          <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="name" required="">
                             </div>

                          
                            <div class="form-group">
                          <label for="exampleInputEmail1">Logo</label>
                          <input type="file" name="logo" class="form-control" id="exampleInputEmail1" placeholder="logo" required="">
                             </div>
                              <div class="form-group">
                          <label for="exampleInputEmail1">Description</label>
                          <input type="text" name="description" class="form-control" id="exampleInputEmail1" placeholder="description" required="">
                             </div>
                             <div class="form-group">
                          <label for="exampleInputEmail1">Gst Number</label>
                          <input type="number" name="gst_number" class="form-control" id="exampleInputEmail1" placeholder="description" required="">
                             </div>
                              <div class="form-group">
                          <label for="exampleInputEmail1">Food</label>
                          <input type="text" name="food" class="form-control" id="exampleInputEmail1" placeholder="food" required="">
                             </div>
                             <div class="form-group">
                          <label for="exampleInputEmail1">License Number</label>
                          <input type="number" name="license_number" class="form-control" id="exampleInputEmail1" placeholder="license_number" required="">
                             </div>
                         

                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/kitchen/add_kitchen.blade.php ENDPATH**/ ?>