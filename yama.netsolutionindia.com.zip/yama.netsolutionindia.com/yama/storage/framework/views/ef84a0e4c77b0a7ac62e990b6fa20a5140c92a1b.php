  <!-- partial:partials/_footer.html -->
  <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2019 <a href="#">InfuenceMe</a>. All rights reserved.</span>
          </div>
        </footer>
        <!-- partial --><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>