<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
                <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
                 <a href="<?php echo e(url('admin/spacetype/create')); ?>" class="btn addLangBtn">
                  ADD SPACE TYPE
                          </a> 
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Space Type Id</th>
                            <th width="5%">Space Type Name</th>
                            <th width="5%">Action</th>
                        </tr>
                      </thead>

                      <tbody>
                        <?php $__currentLoopData = $space_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $space_types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($space_types->id); ?></td>
                            <td><?php echo e($space_types->category); ?></td>
                            <!--<td><a href="<?php echo e(url('admin/spacetype')); ?>/<?php echo e($space_types->id); ?>/edit">Edit</a>
                           <a href="<?php echo e(url('admin/spacetype')); ?>/<?php echo e($space_types->id); ?>/delete">Delete</a></td> -->
                            <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(url('admin/spacetype')); ?>/<?php echo e($space_types->id); ?>/edit" class="dropdown-item" >Edit</a>
                                      <a href="<?php echo e(url('admin/spacetype')); ?>/<?php echo e($space_types->id); ?>/delete" class="dropdown-item" >Delete</a>

                                  </div>
                                </li>
                              </ul>
                            </td>                            
                            
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/space_type/space_type.blade.php ENDPATH**/ ?>