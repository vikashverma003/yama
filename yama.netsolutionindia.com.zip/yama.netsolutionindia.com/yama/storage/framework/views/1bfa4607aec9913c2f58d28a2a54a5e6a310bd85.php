 <!-- plugins:js -->
 <script src="<?php echo e(asset('admin/node_modules/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/popper.js/dist/umd/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/datatables.net/js/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/datatables.net-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/data-table.js')); ?>"></script>
  
  <script src="<?php echo e(asset('admin/node_modules/jquery-bar-rating/dist/jquery.barrating.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/jquery.avgrund/jquery.avgrund.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/jquery.avgrund/jquery.avgrund.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/node_modules/sweetalert2/dist/sweetalert2.min.js')); ?>"></script>

  <script src="<?php echo e(asset('admin/node_modules/jquery-steps/build/jquery.steps.min.js')); ?>"></script>

   <script src="<?php echo e(asset('admin/node_modules/icheck/icheck.min.js')); ?>"></script>
  <!-- <script src="<?php echo e(asset('admin/node_modules/typeahead.js/dist/typeahead.bundle.min.js')); ?>"></script> -->
   <script src="<?php echo e(asset('admin/node_modules/select2/dist/js/select2.min.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('admin/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/misc.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/todolist.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/file-upload.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/iCheck.js')); ?>"></script>
  <!-- <script src="<?php echo e(asset('admin/js/typeahead.js')); ?>"></script> -->

  <script src="<?php echo e(asset('admin/js/select2.js')); ?>"></script>



  <!-- endinject --><?php /**PATH /var/www/html/yama.netsolutionindia.com/yama/resources/views/admin/includes/footer-script.blade.php ENDPATH**/ ?>