<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Owner</h4>
            
             <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/owner')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label>
                          <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="name" required="">
                             </div>
                             <div class="form-group">
                          <label for="exampleInputEmail1">Mobile Number</label>
                          <input type="number" name="mobile_number" class="form-control" id="exampleInputEmail1" placeholder="mobile_number" required="">
                             </div>

                              <div class="form-group">
                          <label for="exampleInputEmail1">Email</label>
                          <input type="text" name="email" class="form-control" id="exampleInputEmail1" placeholder="email" required="">
                             </div>
                             <div class="form-group">
                          <label for="exampleInputEmail1">Password</label>
                          <input type="text" name="password" class="form-control" id="exampleInputEmail1" placeholder="password" required="">
                             </div>
                              <div class="form-group">
                          <label for="exampleInputEmail1">Company Name</label>
                          <input type="text" name="company_name" class="form-control" id="exampleInputEmail1" placeholder="company_name" required="">
                             </div>
                             
                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/owner/add_owner.blade.php ENDPATH**/ ?>