<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
                <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
                <a href="<?php echo e(url('admin/kitchen/create')); ?>" class="btn addLangBtn">
                  ADD VENDOR
                          </a>
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Vendor Id</th>
                            <th width="5%">Vendor Type</th>
                            <th width="5%">Name</th>
                            <th width="5%">Logo</th>
                            <th width="5%">Description</th>
                            <th width="5%">Gst Number</th>
                            <th width="5%">Food</th>
                            <th width="5%">License Number</th>
                            <th width="5%">Action</th>

                        </tr>
                      </thead>

                      <tbody>
                        <?php $__currentLoopData = $kitchen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($kitchens->id); ?></td>
                            <td><?php echo e($kitchens->vendor_type); ?></td>

                            <td><?php echo e($kitchens->name); ?></td>
                            <td><img src="<?php echo e($kitchens->logo); ?>" width="100" height="100" alt="image"/></td>
                            <td><?php echo e($kitchens->description); ?></td>
                            <td><?php echo e($kitchens->gst_number); ?></td>
                            <td><?php echo e($kitchens->food); ?></td>
                            <td><?php echo e($kitchens->license_number); ?></td>
                           <!-- <td><a href="<?php echo e(url('admin/kitchen')); ?>/<?php echo e($kitchens->id); ?>/edit">Edit</a>
                           <a href="<?php echo e(url('admin/kitchen')); ?>/<?php echo e($kitchens->id); ?>/delete">Delete</a></td> -->
                           <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(url('admin/kitchen')); ?>/<?php echo e($kitchens->id); ?>/edit" class="dropdown-item" >Edit</a>
                                      <a href="<?php echo e(url('admin/kitchen')); ?>/<?php echo e($kitchens->id); ?>/delete" class="dropdown-item" >Delete</a>

                                  </div>
                                </li>
                              </ul>
                            </td>                      
                              
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/kitchen/kitchen_listing.blade.php ENDPATH**/ ?>