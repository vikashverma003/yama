
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Edit Group</h4>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/updateGroup')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Food Name</label>
                          <input type="text" name="food_name" class="form-control" id="exampleInputEmail1" value="<?php echo e($data->heading); ?>" placeholder="Enter Name" required="">
                           <input type="hidden" name="id" class="form-control" id="exampleInputEmail1" value="<?php echo e($data->id); ?>" placeholder="Enter Name" required="">
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Restaurants</label>
                          <select class="form-control border-primary" name="restaurants" id="exampleSelectPrimary" required="">
                          <option>--Select--</option>
                          <option value="1" <?php if($data->restaurant_id == '1'){ echo "selected"; } ?>>Pink Sugar</option>
                          <option value="2" <?php if($data->restaurant_id == '2'){ echo "selected"; } ?>>Vintage Machine</option>
                          <option value="3" <?php if($data->restaurant_id == '3'){ echo "selected"; } ?>>The Gourmet Kitchen</option>
                          <option value="4" <?php if($data->restaurant_id == '4'){ echo "selected"; } ?>>The Saffron Boutique</option>
                          <option value="5" <?php if($data->restaurant_id == '5'){ echo "selected"; } ?>>Wasabi by Morimoto</option>
                          </select>
                        </div>

                      <div class="form-group">
                      <label for="exampleTextarea1">Description</label>
                      <textarea class="form-control"  name="description" id="exampleTextarea1" rows="4" required=""><?php echo e($data->description); ?></textarea>
                      </div>

                         <div class="form-group">
                          <label for="exampleInputPassword1">Image</label>
                      <input type="file" name="image" id="professional_title" class="file-upload-default" >
                      <div class="input-group col-xs-12">
                        <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                        <span class="input-group-btn">

                          <button class="file-upload-browse btn btn-info" type="button">Upload</button>
                        </span>

                      </div>
                      <img src="<?php echo e($data->image); ?>" style="width: 45px; height: 45px;">
                      <span id="title_Professional" style="color: red;"></span>
                        </div>


                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/yama.netsolutionindia.com/yama/resources/views/admin/admin/editGroup.blade.php ENDPATH**/ ?>