
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Payment History</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="2%">Series</th>
                            <th width="2%">Image</th>
                            <th width="7%">Patient Name</th>
                            <th width="7%">Patient Email</th>
                            <th width="6%">Doctor ID</th>
                            <th width="7%">Payment Staus</th>
                            <th width="2%">Amount</th>
                            <th width="2%">Admin Status</th>
                            <th width="7%">Created Date</th>
                            <th width="2%">Actions</th>
                        </tr>
                      </thead>
                       <tbody>
                       <?php $i=0; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                          <td> <?php echo $i; ?></td>
                             
                             <?php if(!empty($user->patient['profile_image'])){ ?>
                          <td><img src="<?php echo e(asset($user->patient['profile_image'])); ?>" alt="image" /></td>
                          <?php }else{ ?>

                             <td><img src="<?php echo e(asset('admin/images/dummy-image.jpg')); ?>" alt="image" /></td>
                           <?php } ?>
                        
                            <td><?php echo e(@$user->patient['name']); ?></td>
                            <td><?php echo e(@$user->patient['email']); ?></td>
                            <td><?php echo e(@$user->doctor['random']); ?></td>
                            <td style="color:green;"><?php echo e(@$user->status); ?></td>
                            <td>$<?php echo e(@$user->amount); ?></td>
                              <?php if($user->admin_status == '0'): ?>
                                    <td><label class="badge <?php echo e($user->admin_status == '0' ? 'badge-success' : 'badge-danger'); ?>"> <?php echo e($user->admin_status == '0' ? 'Pending' : 'Paid'); ?></label></td>
                                    <?php else: ?>
                                    <td><label class="badge <?php echo e($user->admin_status == '0' ? 'badge-success' : 'badge-danger'); ?>"> <?php echo e($user->admin_status == '0' ? 'Pending' : 'Paid'); ?></label></td>
                                    <?php endif; ?>
                            <td><?php echo e(@$user->created_at); ?></td>
                            <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(route('viewTransaction',$user->id)); ?>" class="dropdown-item" >View</a>
                                  </div>
                                </li>
                              </ul>
                            </td>
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>

                      <tbody>
                       
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<script type="text/javascript">
  function block_confirmation(id, status)
  {
    swal({
        title: "Are you sure you want to "+status+"?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes, "+status+" it!",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
           url: "<?php echo e(route('block_user')); ?>?user_id="+id+"&status="+status,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }

   function delete_confirmation(id)
  {
    swal({
        title: "Are you sure want to delete this user?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
          url: "<?php echo e(route('delete_user')); ?>?user_id="+id,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vinku.netsolutionindia.com/resources/views/admin/admin/viewPayment.blade.php ENDPATH**/ ?>