<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Valet</h4>
            
             <?php if(session('er_status')): ?>
                  <div class="alert alert-danger"><?php echo session('er_status'); ?></div>
                <?php endif; ?>
                <?php if(session('su_status')): ?>
                  <div class="alert alert-success"><?php echo session('su_status'); ?></div>
                <?php endif; ?>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/valet')); ?>/<?php echo e($valet->id); ?>/update" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label>
                          <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="name" value="<?php echo e($valet->name); ?>" required="">
                             </div>

                        
                            <div class="form-group">
                          <label for="exampleInputEmail1">Driving License Image</label>
                          <input type="file" name="driving_license_image" class="form-control" id="exampleInputEmail1" placeholder="driving_license_image">
                                  <img src="<?php echo e($valet->driving_license_image); ?>" width="300" height="250">
                             </div>
                          <div class="form-group">
                          <label for="exampleInputEmail1">Person Image</label>
                          <input type="file" name="person_image" class="form-control" id="exampleInputEmail1" placeholder="person_image" >
                              <img src="<?php echo e($valet->person_image); ?>" width="300" height="250">

                             </div>
                          <div class="form-group">
                          <label for="exampleInputEmail1">Expiry Data</label>
                          <input type="date" name="expiry_date" class="form-control" id="exampleInputEmail1" placeholder="expiry_date" value="<?php echo e($valet->license_expiry_date); ?>">
                             </div>
                           <div class="form-group">
                          <label for="exampleInputEmail1">DOB</label>
                          <input type="date" name="dob" class="form-control" id="exampleInputEmail1" placeholder="dob" value="<?php echo e($valet->dob); ?>">
                             </div>

                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\yama.netsolutionindia.com\yama\resources\views/admin/valet/edit_valet.blade.php ENDPATH**/ ?>