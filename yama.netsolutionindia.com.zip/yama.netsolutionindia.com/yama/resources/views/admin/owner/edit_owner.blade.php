@extends('admin.layouts.app')

@section('content')
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Owner</h4>
            
             @if (session('er_status'))
                  <div class="alert alert-danger">{!! session('er_status') !!}</div>
                @endif
                @if (session('su_status'))
                  <div class="alert alert-success">{!! session('su_status') !!}</div>
                @endif
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="{{url('admin/owner')}}/{{$owner->id}}/update" method="POST" class="forms-sample" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label>
                          <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="name" value="{{$owner->name}}">
                             </div>
                             <div class="form-group">
                          <label for="exampleInputEmail1">Mobile Number</label>
                          <input type="number" name="mobile_number" class="form-control" id="exampleInputEmail1" placeholder="mobile_number" value="{{$owner->mobile_number}}">
                             </div>

                              <div class="form-group">
                          <label for="exampleInputEmail1">Email</label>
                          <input type="text" name="email" class="form-control" id="exampleInputEmail1" placeholder="email" value="{{$owner->email}}">
                             </div>
                             
                              <div class="form-group">
                          <label for="exampleInputEmail1">Company Name</label>
                          <input type="text" name="company_name" class="form-control" id="exampleInputEmail1" placeholder="company_name" value="{{$owner->company_name}}">
                             </div>
                             
                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

@endsection