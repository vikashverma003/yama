@extends('admin.layouts.app')

@section('content')
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Edit Parking Space</h4>
             <div>
             @if (session('er_status'))
                  <div class="alert alert-danger">{!! session('er_status') !!}</div>
                @endif
                @if (session('su_status'))
                  <div class="alert alert-success">{!! session('su_status') !!}</div>
                @endif
              </div>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="{{url('admin/edit_parking_space')}}/{{$parking_space->id}}" method="POST" class="forms-sample" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                          <label for="exampleInputEmail1">Parking Space</label>
                          <input type="text" name="parking_space" class="form-control" id="exampleInputEmail1" placeholder="space" value="{{$parking_space->parking_space}}">
                             </div>

                             <div class="form-group">
                          <label for="exampleInputEmail1">Status</label>
                          <input type="number" name="status" class="form-control" id="exampleInputEmail1" placeholder="status" value="{{$parking_space->status}}" min='0' max='1'>
                             </div>
                          <div class="form-group">
                          <label for="exampleInputEmail1">In Use</label>
                          <input type="number" name="in_use" class="form-control" id="exampleInputEmail1" placeholder="in_use" value="{{$parking_space->in_use}}" min='0' max='1'>
                             </div>
                           <div class="form-group">
                          <label for="exampleInputEmail1">Shop Id</label>
                          <input type="text" name="shop_id" class="form-control" id="exampleInputEmail1" value="{{$parking_space->shop_id}}" placeholder="shop_id">
                             </div>

                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

@endsection