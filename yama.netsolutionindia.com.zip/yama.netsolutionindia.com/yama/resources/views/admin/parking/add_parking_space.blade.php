@extends('admin.layouts.app')

@section('content')
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Parking Space</h4>
            
             @if (session('er_status'))
                  <div class="alert alert-danger">{!! session('er_status') !!}</div>
                @endif
                @if (session('su_status'))
                  <div class="alert alert-success">{!! session('su_status') !!}</div>
                @endif
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="{{url('admin/store_parking_space')}}" method="POST" class="forms-sample" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                          <label for="exampleInputEmail1">Parking Space</label>
                          <input type="text" name="parking_space" class="form-control" id="exampleInputEmail1" placeholder="space" required="">
                             </div>

                             <div class="form-group">
                          <label for="exampleInputEmail1">Status</label>
                          <input type="number" name="status" class="form-control" id="exampleInputEmail1" placeholder="status" required="" min='0' max='1'>
                             </div>
                          <div class="form-group">
                          <label for="exampleInputEmail1">In Use</label>
                          <input type="number" name="in_use" class="form-control" id="exampleInputEmail1" placeholder="in_use" required="" min='0' max='1'>
                             </div>
                           <div class="form-group">
                          <label for="exampleInputEmail1">Shop Id</label>
                          <input type="text" name="shop_id" class="form-control" id="exampleInputEmail1" placeholder="shop_id">
                             </div>

                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

@endsection