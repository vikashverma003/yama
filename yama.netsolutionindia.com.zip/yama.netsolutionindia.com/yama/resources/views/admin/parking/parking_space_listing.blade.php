@extends('admin.layouts.app')
@section('content')
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
                @if (session('er_status'))
                  <div class="alert alert-danger">{!! session('er_status') !!}</div>
                @endif
                @if (session('su_status'))
                  <div class="alert alert-success">{!! session('su_status') !!}</div>
                @endif
                <a href="{{url('admin/add_parking_space')}}" class="btn addLangBtn">
                  ADD PARKING SPACE
                          </a>
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Parking Id</th>
                            <th width="5%">Parking Space</th>
                            <th width="5%">Status</th>
                            <th width="5%">In_use</th>
                            <th width="5%">shop_id</th>
                            <th width="5%">Parking status</th>
                            <th width="5%">Allocated status</th>
                            <th width="5%">Edit Parking Space</th>
                            <th width="5%">Delete Parking </th>

                        </tr>
                      </thead>

                      <tbody>
                        @foreach($parking_space as $parking_spaces)
                        <tr>
                            <td>{{$parking_spaces->id}}</td>
                            <td>{{$parking_spaces->parking_space}}</td>
                            <td>{{$parking_spaces->status}}</td>
                            <td>{{$parking_spaces->in_use}}</td>
                            <td>{{$parking_spaces->shop_id}}</td>
                            <td>
                              <a href="{{url('/admin/update_parking_space')}}/{{$parking_spaces->id}}">update status</a>
                            </td> 
                            <td>
                              <a href="{{url('/admin/update_parking_allocation')}}/{{$parking_spaces->id}}">Allocated status</a>
                            </td>  
                            <td>
                              <a href="{{url('/admin/edit_parking_space')}}/{{$parking_spaces->id}}">Edit Space</a>
                            </td> 
                            <td>
                              <a href="{{url('/admin/delete_parking')}}/{{$parking_spaces->id}}">delete </a>
                            </td>                            
                        </tr>
                        @endforeach
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
@endsection